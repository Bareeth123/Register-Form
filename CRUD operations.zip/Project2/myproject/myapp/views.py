from django.shortcuts import render
from .models import Vinsup

def register(request):
    if request.method == 'POST':
        name = request.POST['name']
        age = request.POST['age']
        gender = request.POST['gender']
        qualification = request.POST['qualification']
        email = request.POST['email']
        address = request.POST['address']
        license = request.POST['license']
        govt_id1 = request.POST['id_proof1']
        govt_id2 = request.POST['id_proof2']
        govt_id3 = request.POST['id_proof3']
        Employee = Vinsup(Name=name, Age=age, Gender=gender, Qualification=qualification, Email=email, Address=address, License=license, Govt_id=[govt_id1,govt_id2,govt_id3])
        Employee.save()
        return render(request, 'result.html')
    return render(request, 'register.html')


