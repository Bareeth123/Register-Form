from django.db import models

class Vinsup(models.Model):
    Name = models.CharField(max_length=100, null=False)
    Age = models.IntegerField()
    Gender = models.CharField(max_length=10)
    Qualification = models.CharField(max_length=10)
    Email = models.EmailField()
    Address = models.CharField(max_length=50,null=True)
    License = models.CharField(max_length=10)
    Govt_id = models.CharField(max_length=40)
